# 微信 Clawbot

把微信（WeChat）当作 EnsoCode 秘书的一个联系方式。扫码的那个人发来的文字和语音转写会交给秘书，秘书的回复再发回微信。

需要 EnsoCode 0.3.9 及以上（这一版才有 `secretary.contact`）。

## 登录

1. 在插件市场安装并启用「微信 Clawbot」。
2. 打开秘书的联系方式，选「微信」，点「扫码登录」。
3. 用微信扫描页面上的二维码，并在手机上确认。如果手机上出现数字，把数字填进页面。

只接收扫码者本人的消息。图片、文件和视频第一版不支持，会回一句「暂不支持图片、文件和视频」；和文字一起发时文字照常处理，再回一句「暂不支持图片、文件和视频，只处理了文字」。语音没有转写文字时不交给秘书，回一句「这条语音没能转成文字，麻烦再发一次或者打字」。每条消息最多回一句说明。

交给秘书时带上发送者 id（iLink 协议的 `from_user_id`），会话 id 也是它，回复发回同一个 `to_user_id`。协议里的 `group_id` 只是类型字段，`sendmessage` 没有群目标，所以不当成群处理：带 `group_id` 的消息不标私聊，也不标群。

秘书可以给你发图片和文件：按微信 iLink 协议先用 `getuploadurl` 拿上传地址，把内容用随机密钥做 AES-128-ECB 加密后上传到微信 CDN（`novac2c.cdn.weixin.qq.com`），再用 `sendmessage` 发出图片或文件消息；带说明时先单独发一条文字。单个不超过 10MB，由 EnsoCode 限制。发送失败时 EnsoCode 会另回一句说明和电脑上的路径。

「退出登录」会清掉本机保存的登录状态并停止收消息。登录失效时页面会要求重新扫码。

微信只允许机器人在你最近发来消息之后回复：每条入站消息带一个会话令牌（`context_token`），发送要用它。还没收到过你的消息，或者令牌已失效（`sendmessage` 返回 `ret=-2`）时，发送直接失败，提示「微信会话已过期，请在微信给机器人发任意一条消息后恢复」，错误同时带 `code: SESSION_EXPIRED` 和 `userMessage`。失效的令牌会被丢掉，之后的发送不再请求微信，直到你再发来一条消息。

二维码在页面里本地生成，不访问外网。生成器是 Kazuhiko Arase 的 QR Code Generator（MIT），见 `lib/qrcode.js`。

## 权限

| 权限 | 用途 |
| --- | --- |
| `secretary.contact` | 注册「微信」联系方式，把消息交给秘书并发送回复 |
| `net.fetch` | 访问微信 iLink（`ilinkai.weixin.qq.com`，以及扫码后跳到的 `*.weixin.qq.com`），上传图片和文件到微信 CDN（`novac2c.cdn.weixin.qq.com`） |
| `process.background` | 常驻长轮询新消息 |
| `ui.view` | 扫码登录页 |
