# Lunar 月白 · EnsoCode 宇航员主题

黑白大头宇航员搭配高对比中性灰阶界面，提供浅色与深色两套九色调色板、细边框和克制的语义状态色。

适用于 **EnsoCode 0.3.3 及以上版本**。

## 界面预览

![Lunar 月白深色界面预览](https://raw.githubusercontent.com/mediocrebaby/Astronauts/main/design/host-preview-dark.png)

![Lunar 月白浅色界面预览](https://raw.githubusercontent.com/mediocrebaby/Astronauts/main/design/host-preview-light.png)

## 轨道舱界面

- 顶部：全宽月面地平线、轨道弧线与月球轮廓，搭配每 26 秒移向另一侧的月光和每 14 秒划过的底边高光。
- 标识与标题：宽窗口在原有顶部工具按钮后显示 Lunar 铭牌，工作区标题区域采用半透明面板。
- 侧栏：渐隐竖向刻度、首尾微亮的分隔线、会话与自定义项目分组的浅浮雕选中态；“全部 / 最近”保留原生文字强调与底部移动下划线。
- 停泊区：太空人下方加入静态轨道环及 Lunar Module 铭文；折叠侧栏时隐藏停泊插画。

界面样式位于 `themes/lunar/chrome.css`，使用 EnsoCode 的 `title-bar`、`sidebar` 稳定锚点，保留原有按钮、项目列表和原生窗口操作。装饰层不拦截鼠标，顶部保持宿主原有高度。开启系统“减少动态效果”后，顶部停止光影动画，侧栏使用静态首帧。

## 角色素材

角色形象使用经确认的生图原稿 `design/approved.png`，侧栏动画按同一形象在 Blender 中建模渲染。透明底素材位于 `themes/lunar/`：

| 文件 | 装饰位 |
| --- | --- |
| `float.png` | `empty-main` 空会话 |
| `wave.png` | `welcome` 欢迎画面：挥手迎接 |
| `turn.webp` | `sidebar-footer` 侧栏底部：固定斜轴的三维转身 |
| `turn-still.png` | 减少动态效果时显示的静态首帧 |
| `peek.png` | `composer-peek` 输入框 |
| `helmet.png` | `status-icon` 状态栏 |

侧栏太空人保持倾斜的头脚轴，从正面转到侧面、背面再回到正面。96 个独立渲染帧，3 秒一圈（32fps），使用 EnsoCode 原生图片装饰位播放，无需额外主题 CSS。开启系统“减少动态效果”后，宿主使用 `still` 素材显示静态首帧。

建模源码为 `scripts/render-3d.py`，动画打包源码为 `scripts/pack-3d.py`，可编辑工程为 `design/3d/lunar-astronaut.blend`。完整复现步骤见 `design/3d/README.md`。

## 安装与设置

在仓库根目录运行 `npm run build`，生成 `dist/space-astronaut-1.5.0.zip`。在 EnsoCode 的设置 → 插件中选择从压缩包安装该文件，或从文件夹安装本仓库；更新时允许插件的**主题样式能力**，顶部与侧栏设计由此加载。启用后在设置 → 外观 → 主题选择 **Lunar 月白**，并在主题模式中选择浅色、深色或跟随系统。强调色设为跟随主题时使用主题灰阶。

## 开发与预览

```sh
npm test
npm run validate
npm run build
npm run preview
npm run preview:host
```

`dist/host-preview.html` 使用从宿主核对的顶部与侧栏结构，原样加载安装包 CSS，可切换深浅色、折叠侧栏和选中会话。`dist/preview.html` 展示两种配色和角色装饰位；已确认的完整视觉构图保留在 `dist/titlebar-preview.html`。这些文件是独立浏览器预览，实际安装表现需在 EnsoCode 中核对。

打包只包含清单、清单与主题引用的资源和 README；原稿与预览代码不进入安装包。

## 市场发布目录

运行 `npm run stage:market`，将与本地安装包一致的 11 个运行文件同步到 `marketplace/space.astronaut/`。该目录随源码提交，供[官方插件市场](https://github.com/J3n5en/enso-plugins)通过固定的完整提交 SHA 引用。建模工程、设计参考、开发脚本和测试不进入市场安装包。

更新主题后，先运行测试、校验和 `npm run stage:market`，提交并推送；再向市场提交 PR 更新外部声明中的提交 SHA。发布新内容时提升插件版本号。
